# Shared tools audit and application integration

@devxcrew/tools is useful for this workspace. It is development tooling, not an application runtime dependency. The npm registry currently provides 0.1.2. Cxsun uses a locally packed 0.1.2 snapshot that includes the compatibility changes below. Nothing was published or pushed.

## Compatible and verified

- App builds: consuming TypeScript 7, Vite, and app-owned compiler configurations.
- App development: one server hosting the frontend, APP_HOST/APP_PORT/APP_URL, environment loading, and framework preparation.
- Port preflight: preserves the configured port and defaults to abort when occupied for single-server apps. Ownership-aware restart remains optional.
- Environment initialization: preserves existing .env; copies .env.example when absent. Cookie secrets are generated only when the sample defines COOKIE_SECRET.
- Dependency checks: current @codexsun framework/UI names, explicit local package opt-in, and backend package exclusion from frontend source.
- Boundary parsing: Cxsun uses its TypeScript 6 parser alias because the TypeScript 7 compiler does not provide the previous parser API.
- Formatting, line endings, local version reporting, package packing, and regression tests.

## Separate or deferred

Package build/package:check assumes compiled dist/src exports; do not apply it to Cxsun or source-exported shared UI. app:clone-check and container:prepare still assume the previous starter layout. They are not wired to Cxsun. Docker is deferred. Version bumps require the documented changelog contract. GitHub commands can commit and push and are not connected to Cxsun scripts.

Old creation-package references were removed from current dependency rules and documentation. Historical changelog entries remain intact.

## Repeat for another application

1. Install the local packed @devxcrew/tools archive as a devDependency. Use the published npm version only after a release containing these changes exists.
2. Copy the application configuration from D:\codexsun\projects\cxsun\.devxcrew-tools.json and adjust source paths.
3. Set app.mode to single-server, envFile to .env, and beforeBuild to the owning application's preparation script.
4. Define APP_NAME, APP_PORT, APP_URL, APP_MODE, and APP_HOST in .env.example.
5. Set dev to devxcrew-tools app:dev and build to devxcrew-tools app:build. Add tools:check and tools:env scripts from Cxsun.
6. Run npm run check, npm run build, the application's production smoke check, and npm run dev. Verify that the configured port and frontend routes work.

Repack from shared/tools with npm run pack after tooling changes. Reinstall that archive explicitly in consuming apps so their lockfile records the new archive integrity.

## Verification

18 tools regression tests pass, including single-server port settings and compiler resolution with restricted package exports. Cxsun dependency boundaries, lint, type checks, tests, package installation, app build, frontend serving, and tools-managed dev startup pass. GitHub tests use temporary local repositories; no cloud Git operation was performed.
